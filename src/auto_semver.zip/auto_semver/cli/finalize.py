import logging

from auto_semver.config import Config
from auto_semver.gh import GitHubEvent
from auto_semver.git import GitOps
from auto_semver.semver import SemverLock

logger = logging.getLogger(__name__)

def run(*, gitops: GitOps, event: GitHubEvent, config: Config) -> None:
    target_branch: str = event.get_target_branch_name()
    version = SemverLock.load_from_file().version
    allowed_targets = list(config.data.suffixes.keys())

    logger.info("Tagging branch")

    if target_branch not in allowed_targets:
        logger.debug(f"Target branch '{target_branch}' not allowed for tagging. Allowed: {allowed_targets}")
        raise ValueError(f"Tagging not allowed on branch '{target_branch}'.")

    gitops.tag(tag=str(version), branch=target_branch)