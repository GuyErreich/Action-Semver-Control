"""
Configuration management for auto-semver-bump.

This module provides a class for loading and validating configuration
settings from a YAML file. It ensures that required keys are present
and provides methods to access various configuration options.

Typical usage::
    config = Config()
    version_files = config.get_files_to_update()
    start_version = config.get_start_version()
    suffix = config.get_suffix("main")
    branch_strategy = config.get_branch_strategy()
    label = config.get_pr_labels()
    changelog_file = config.get_changelog_file()
    should_truncate_changelog = config.should_truncate_changelog()
    changelog_template = config.get_changelog_template()
    changelog_header = config.get_changelog_header()
    changelog_footer = config.get_changelog_footer()
"""

import logging
import os
from typing import Any

import yaml
from pydantic import ValidationError

from .data import ConfigData

logger = logging.getLogger(__name__)

CONFIG_FILE: str = "auto_semver_config.yml"

class Config:

    """
    Configuration management class for auto-semver-bump.

    This class loads configuration settings from a YAML file and provides
    methods to access various configuration options. It ensures that
    required keys are present and provides default values for optional
    settings.
    """

    def __init__(self, path: str = CONFIG_FILE) -> None:
        """
        Initialize the configuration manager.

        Args:
            path (str): Path to the configuration file. Defaults to 'auto_semver_config.yml'.

        Raises:
            RuntimeError: If the configuration file is invalid or missing required keys.
            KeyError: If a required key is missing in the configuration file.

        """
        self.path = path
        self.path = path
        self.data = self._load_and_parse()

    def _load_and_parse(self) -> ConfigData:
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"Configuration file '{self.path}' not found.")

        try:
            with open(self.path, encoding='utf-8') as f:
                raw_config = yaml.safe_load(f) or {}
            return ConfigData(**raw_config)
        except yaml.YAMLError as err:
            logger.error(f"Error parsing YAML configuration: {err}")
            raise
        except ValidationError as e:
            logger.error(f"Configuration validation error: {e}")
            raise

    def __getattr__(self, item: str) -> Any:
        return getattr(self.data, item)
